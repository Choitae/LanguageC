#include <stdio.h>

int my_sum(int a, int b) {
	return a + b;
}

void main() {
	printf("sum : %d", my_sum(5, 6));     // sum : 11
}