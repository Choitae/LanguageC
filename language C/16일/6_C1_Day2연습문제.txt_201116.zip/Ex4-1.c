#include <stdio.h>

void main ( ) {
	int a = 10, b = 20;
	// ��� : a + b = 30
	printf ( "a + b = %d\n", a + b );
	//	      a - b = -10
	printf ( "a - b = %d\n", a - b );
	//        a * b = 300
	printf ( "a * b = %d\n", a * b );
	//        b / a = 2
	printf ( "b / a = %d\n", b / a );
	//        a % b = 10
	printf ( "a %% b = %d\n", a % b );
}

