#include <stdio.h>  
  /*
  A B
+ B A
------
8 8
*/
void main() {
	for (int a = 0; a <= 9; a++) {	// a : 0 ~ 9
		for (int b = 0; b <= 9; b++) {   // b : 0 ~ 9
			if ((10 * a + b) + (10 * b + a) == 88) {
				if (a != 0 && b != 0) {
					printf("a:%d, b:%d\n", a, b);
				}
			}
		}
	}
}



