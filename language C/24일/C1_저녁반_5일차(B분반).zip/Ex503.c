#include <stdio.h>

void main() {
	int sum = 0;
	for (int i = 1; i <= 4; i++) {   // i : 1 ~ 4
		sum = sum + i;		// sum = sum(=0) + 1;
	}						// sum = sum(=1) + 2;
							// sum = sum(=3) + 3;
							// sum = sum(=6) + 4;
	printf("1���� 4���� �հ� : %d\n", sum);
}
