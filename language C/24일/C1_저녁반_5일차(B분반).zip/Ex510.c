#include <stdio.h>

void print_stars(int a, int b) {
	for (int i = a; i <= b; i++) {   // i : a ~ b
		// *�� i�� ���.
		for (int j = 1; j <= i; j++) {
			printf("*");
		}
		printf("\n");
	}
}

void main() {
	print_stars(2, 5);
}