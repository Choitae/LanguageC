#include <stdio.h>

void main ( ) {
	int a = 20, b = 10;

	printf ( "%d + %d = %d\n", a, b, a + b );
	printf ( "%d - %d = %d\n", a, b, a - b );
	printf ( "%d * %d = %d\n", a, b, a * b );
	printf ( "%d / %d = %d\n", a, b, a / b );

}